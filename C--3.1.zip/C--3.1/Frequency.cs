﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Goose1
{
    public enum Frequency
    {
        weekly,
        monthly,
        yearly,
    }
}
